import { Component } from 'react';
import './footer.scss';

class Footer extends Component {
    render(){
        return(
            <div className='footertDiv'>
                <ul className='footerBar'>
                    <li><a href="#">Coffe house</a></li>
                    <li><a href="#">Our coffee</a></li>
                    <li><a href="#">For your pleasure</a></li>
                </ul>
            </div>
                
        );
    }
}


export default Footer;