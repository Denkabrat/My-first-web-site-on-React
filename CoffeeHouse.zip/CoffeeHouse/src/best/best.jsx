import { Component } from 'react';
import './best.scss';

class Best extends Component {
    render(){
        return(
            <div className='bestDiv'>
                <img src="https://peterburg2.ru/uploads/20/08/25/o_paper-1074131_1920.jpg" alt="background" />
                    <span className='ourBest'>Our best</span>
                    <div className="box_cards">
                        <div className="box_card">
                            <img src="https://avatars.mds.yandex.net/get-mpic/5236304/img_id7137306595123713733.png/orig" alt="coffeePac" /><br />
                            <span className='nameProduct'>Solimo Coffee Beans 2 kg</span>
                            <span className='priceProduct'>10.73$</span>
                        </div>
                        <div className="box_card">
                            <img src="https://expertology.ru/upload/medialibrary/531/Danesi.webp" alt="coffeePac" /><br />
                            <span className='nameProduct'>Presto Coffee Beans 1 kg</span>
                            <span className='priceProduct'>14.99$</span>
                        </div>
                        <div className="box_card">
                            <img src="https://ir.ozone.ru/s3/multimedia-b/c1000/6147782927.jpg" alt="coffeePac" /><br />
                            <span className='nameProduct'>AROMISTICO Coffee 1 kg</span>
                            <span className='priceProduct'>22.50$</span>
                        </div>
                    </div>
                   
            </div>
                
        );
    }
}


export default Best