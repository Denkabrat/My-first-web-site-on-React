import { Component } from 'react';
import './header.scss';

class Header extends Component {
    render(){
        return(
            <div>
                <header className='HeaderTop'>
                    <ul>
                        <li><a href="#">Coffe house</a></li>
                        <li><a href="#">Our coffee</a></li>
                        <li><a href="#">For your pleasure</a></li>
                    </ul>
                </header>
                <nav>
                    <img className='HeaderCoffee' src="https://i.pinimg.com/originals/30/61/41/306141ace1d9b18cb090998edcdb5d90.jpg" alt="CoffeTable" />
                    <h1>Everything You Love About Coffee</h1>
                            <h2>We makes every day full of energy and taste <br></br> Want to try our beans?</h2>
                    <button>More</button>
                </nav>
                
                
            </div>
        );
    }


}

export default Header;

