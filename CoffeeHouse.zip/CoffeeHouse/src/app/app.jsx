import About  from '../about/about';
import Header from '../header/header';
import Best   from '../best/best';
import Footer from '../footer/footer';

import './app.scss'


function App(){

    return(
        <div className='Header'>
            <Header/>
            <About/>
            <Best/>
            <Footer/>
        </div>
    );
}

export default App;